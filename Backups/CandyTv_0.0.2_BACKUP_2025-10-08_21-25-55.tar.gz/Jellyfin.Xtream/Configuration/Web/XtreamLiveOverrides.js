export default function (view) {
  view.addEventListener("viewshow", () => import(
    ApiClient.getUrl("web/ConfigurationPage", {
      name: "Xtream.js",
    })
  ).then((Xtream) => Xtream.default
  ).then((Xtream) => {
    const pluginId = Xtream.pluginConfig.UniqueId;
    Xtream.setTabs(5);

    // Placeholder für zukünftige Stream-Optimierungen
    const infoContainer = view.querySelector('#optimizationsInfo');
    infoContainer.innerHTML = `
      <div style="background: #2a2a2a; padding: 30px; border-radius: 8px; text-align: center;">
        <h3 style="color: #00a4dc; margin-top: 0;">Stream-Optimierungen</h3>
        <p style="color: #aaa; font-size: 16px; line-height: 1.6;">
          Hier werden in Zukunft Funktionen zur Optimierung der Streams verfügbar sein.
        </p>
        <p style="color: #888; font-size: 14px; margin-top: 20px;">
          Diese Seite wird später erweitert.
        </p>
      </div>
    `;
  }));
}